<x-home-layout>
    <div class="w-full max-w-3xl mx-auto p-8">
        <h1 class="text-3xl font-bold mt-10 mb-10">Tentang Kami</h1>
        <article class="prose prose-md w-full max-w-none ">
            {!! $about->render() !!}
        </article>
    </div>
</x-home-layout>
