<select name="<?php echo e($name); ?>" id="<?php echo e($id); ?>"
    class="w-full text-sm py-3 px-4 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-transparent">
    <option value="" selected disabled><?php echo e($placeholder); ?></option>
    <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($option['value']); ?>" <?php echo e($selected == $option['value'] ? 'selected' : ''); ?>>
            <?php echo e($option['label']); ?>

        </option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>

<?php /**PATH /home/xirf/00.Projects/02.PHP/posyandu/resources/views/components/select.blade.php ENDPATH**/ ?>