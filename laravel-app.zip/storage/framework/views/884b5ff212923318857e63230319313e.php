<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /home/xirf/00.Projects/02.PHP/posyandu/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/header.blade.php ENDPATH**/ ?>