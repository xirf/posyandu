<?php if (! $__env->hasRenderedOnce('d0197144-968a-4b4d-a2ce-e7ae7cb5b3b5')): $__env->markAsRenderedOnce('d0197144-968a-4b4d-a2ce-e7ae7cb5b3b5');
$__env->startPush('styles'); ?>
    <link href="/css/quill.snow.css" rel="stylesheet">
<?php $__env->stopPush(); endif; ?>

<?php if (! $__env->hasRenderedOnce('2246ec7b-00e8-4067-a4c6-53135f9934e0')): $__env->markAsRenderedOnce('2246ec7b-00e8-4067-a4c6-53135f9934e0');
$__env->startPush('scripts'); ?>
    <script src="/js/quill.js" defer></script>
    <script src="/js/quill-image-resize.js" defer></script>
<?php $__env->stopPush(); endif; ?>

<div class="mb-5" x-data="{
    content: '',
    availableImages: [],
    selectedImage: null,
    isImageLoading: true,
    endpoint: '<?php echo e($endpoint ?? ''); ?>',
    csrf: '<?php echo e(csrf_token()); ?>',
    selectLocalImage() {
        const input = document.createElement('input');
        input.setAttribute('type', 'file');
        input.click();

        input.onchange = () => {
            const file = input.files[0];
            if (/^image\//.test(file.type)) {
                this.saveToServer(file);
            } else {
                console.warn('You could only upload images.');
            }
        };
    },
    saveToServer(file) {
        const fd = new FormData();
        fd.append('image', file);

        const xhr = new XMLHttpRequest();
        xhr.open('POST', this.endpoint, true);
        xhr.setRequestHeader('X-CSRF-Token', this.csrf);

        xhr.upload.onprogress = function(event) {
            var progress = Math.round(event.loaded / event.total * 100) + '%';
            var progressBar = document.getElementById('quillProgressBar');
            if (event.lengthComputable) {
                progressBar.style = `width: ${parseFloat(progress)}`;
                if (event.loaded == event.total) {
                    progressBar.style = 'width: 0%';
                }
            }
        };

        xhr.onload = function() {
            if (this.status >= 200 && this.status < 300) {
                const data = JSON.parse(this.responseText);
                const range = quill.getSelection();
                quill.insertEmbed(range.index, 'image', `/${data.url}`);
                quill.setSelection(range.index + 1, Quill.sources.SILENT);
                $dispatch('close-modal', 'add-image');
            }
        };
        xhr.send(fd);
    },
    insertSelectedImage() {
        if (this.selectedImage) {
            const range = quill.getSelection();
            quill.insertEmbed(range.index, 'image', this.selectedImage.replace('public/', '/storage/'));
            quill.setSelection(range.index + 1, Quill.sources.SILENT);
            $dispatch('close-modal', 'add-image');
        }
    }
}" x-init="document.addEventListener('DOMContentLoaded', () => {
    quill = new Quill($refs.quillEditor, {
        scrollingContainer: '.ql-scrolling-container',
        modules: {
            history: {
                delay: 2000,
                maxStack: 500,
                userOnly: true
            },
            toolbar: {
                container: [
                    [{ 'header': [1, 2, 3, 4, 5, 6, false] }, 'bold', 'italic', 'underline', 'strike', { 'color': [] }, { 'background': [] }],
                    ['link', 'blockquote', 'image'],
                    [{ list: 'ordered' }, { list: 'bullet' }, { 'align': [] }],
                    [{ 'indent': '-1' }, { 'indent': '+1' }],
                    ['clean', { 'undo': 'undo' }, { 'redo': 'redo' }]
                ],
                handlers: {
                    image: () => {
                        $dispatch('open-modal', 'add-image');
                    },
                    undo: () => {
                        this.quill.history.undo();
                    },
                    redo: () => {
                        this.quill.history.redo();
                    }
                }
            },
            imageResize: {
                displaySize: true
            },
        },
        theme: 'snow',
        placeholder: '<?php echo e($placeholder ?? 'Write something great!'); ?>'
    });
    quill.on('text-change', function() {
        let html = quill.root.innerHTML;
        if (html === '<p><br></p>') html = ''
        content = html;
    });

    if (document.getElementById('quill-initial-data')) {
        quill.setContents(JSON.parse(document.getElementById('quill-initial-data').textContent.replaceAll('\n', '')));
    }

    content = (quill.root.innerHTML === '<p><br></p>') ? '' : quill.root.innerHTML;
});

document.querySelector('#<?php echo e($formId); ?>').addEventListener('formdata', (event) => {
    event.formData.append('<?php echo e($name ?? 'about'); ?>', JSON.stringify(quill.getContents().ops));
});" x-cloak>

    <?php if($label ?? null): ?>
        <label for="<?php echo e($name); ?>" class="form-label block mb-1 font-semibold text-gray-700">
            <?php echo e($label); ?>

            <?php if($optional ?? null): ?>
                <span class="text-sm text-gray-500 font-normal">(optional)</span>
            <?php endif; ?>
        </label>
    <?php endif; ?>

    <div class="relative <?php echo e($errors->has($name) ? 'ql-editor-haserror' : ''); ?>">
        <div class="w-full pl-px pr-px bg-transparent z-20 absolute left-0 right-0" style="top: 38px;">
            <div id="quillProgressBar" class="bg-green-600 text-xs leading-none h-1" style="width: 0%"></div>
        </div>

        <textarea class="hidden" name="<?php echo e($name); ?>" :value="content"></textarea>
        <div x-ref="quillEditor" x-model="content"
            class="bg-white min-h-full h-auto focus-visible:outline-none focus:outline-cyan-600">
            <?php echo old($name, $value ?? ''); ?>

        </div>

        <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <svg class="absolute z-10 text-red-600 fill-current w-5 h-5" style="top: 12px; right: 12px"
                xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                <path
                    d="M11.953,2C6.465,2,2,6.486,2,12s4.486,10,10,10s10-4.486,10-10S17.493,2,11.953,2z M13,17h-2v-2h2V17z M13,13h-2V7h2V13z" />
            </svg>
            <div class="text-red-600 mt-2 text-sm block leading-tight"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <?php if (isset($component)) { $__componentOriginal9f64f32e90b9102968f2bc548315018c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9f64f32e90b9102968f2bc548315018c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['name' => 'add-image']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'add-image']); ?>
        <div class="p-6 space-y-6" x-on:close-modal.window="isImageLoading=false"
            x-on:open-modal.window="
            isImageLoading=true; fetch('<?php echo e(route('get.images')); ?>', { method: 'GET', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json', } }).then(response => response.json()).then(x=> availableImages=x).catch(e => alert(e.message)).finally(() => isImageLoading=false);">

            <h2 class="text-lg font-medium text-gray-900">
                <?php echo e(__('Add Image')); ?>

            </h2>

            <div class="mt-6 grid grid-cols-5 gap-2 max-h-96 overflow-y-auto">
                <template x-for="(image, index) in availableImages" :key="index">
                    <div class="w-full h-full">
                        <label x-bind:for="image"
                            class="w-full h-full rounded-md border aspect-square object-contain block overflow-hidden relative"
                            :class="selectedImage === image ? 'border-2 border-cyan-500' : 'border-none'">
                            <input type="radio" name="selected_image" x-bind:id="image"
                                x-on:change="selectedImage = image" class="hidden">
                            <img x-bind:src="image.replace('public/', '/storage/')" class="w-full h-full object-cover"
                                x-bind:alt="image">
                            <div class="absolute bottom-2 left-2 rounded-full p-1 bg-cyan-500"
                                x-show="selectedImage === image" x-transition:enter="transition ease-out duration-300"
                                x-transition:enter-start="opacity-0 transform scale-90"
                                x-transition:enter-end="opacity-100 transform scale-100"
                                x-transition:leave="transition ease-in duration-300"
                                x-transition:leave-start="opacity-100 transform scale-100"
                                x-transition:leave-end="opacity-0 transform scale-90">
                                <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('heroicon-o-check-circle'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\BladeUI\Icons\Components\Svg::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-6 h-6 text-white']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
                            </div>
                        </label>
                    </div>
                </template>
            </div>
            <div class="flex justify-end space-x-2">
                <?php if (isset($component)) { $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.secondary-button','data' => ['xOn:click' => 'selectLocalImage()','type' => 'button']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('secondary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['x-on:click' => 'selectLocalImage()','type' => 'button']); ?>
                    <?php echo e(__('Upload Image')); ?>

                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $attributes = $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $component = $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginald411d1792bd6cc877d687758b753742c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald411d1792bd6cc877d687758b753742c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-button','data' => ['xOn:click' => 'insertSelectedImage','type' => 'button']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('primary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['x-on:click' => 'insertSelectedImage','type' => 'button']); ?>
                    <?php echo e(__('Insert Selected Image')); ?>

                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $attributes = $__attributesOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__attributesOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $component = $__componentOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__componentOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
            </div>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $attributes = $__attributesOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__attributesOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $component = $__componentOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__componentOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
</div>
<?php /**PATH /home/xirf/00.Projects/02.PHP/posyandu/resources/views/components/quill.blade.php ENDPATH**/ ?>