<?php if (! $__env->hasRenderedOnce('0ac08cd8-3efc-4a72-ac49-980083c470ce')): $__env->markAsRenderedOnce('0ac08cd8-3efc-4a72-ac49-980083c470ce');
$__env->startPush('styles'); ?>
    <link rel="stylesheet" href="/css/tom-select.css">
    <style>
        .icon {
            width: 3rem;
        }

        .ts-wrapper.loading {
            aspect-ratio: unset;
            -webkit-mask-image: none;
            mask-image: none;
        }

        .ts-control:has(input:focus) {
            border-color: rgb(6 182 212);
            outline-style: solid;
            outline-width: 1px;
            outline-color: rgb(6 182 212);
        }
    </style>
<?php $__env->stopPush(); endif; ?>

<div class="w-full">
    <?php if (isset($component)) { $__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-label','data' => ['for' => 'name','value' => __('Name'),'required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'name','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Name')),'required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581)): ?>
<?php $attributes = $__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581; ?>
<?php unset($__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581)): ?>
<?php $component = $__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581; ?>
<?php unset($__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581); ?>
<?php endif; ?>
    <select id="select-patient" name="name" class="mt-1 block w-full text-sm" required>
    </select>
    <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->createReport->get('nama'),'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->createReport->get('nama')),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
</div>
<div class="w-full">
    <?php if (isset($component)) { $__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-label','data' => ['for' => 'gender','value' => __('Gender'),'required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'gender','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Gender')),'required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581)): ?>
<?php $attributes = $__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581; ?>
<?php unset($__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581)): ?>
<?php $component = $__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581; ?>
<?php unset($__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581); ?>
<?php endif; ?>
    <select id="gender" name="gender"
        class="mt-1 block w-full border-gray-300 focus:border-cyan-500 focus:ring-cyan-500 rounded-md shadow-sm text-sm"
        placeholder="<?php echo e(__('Choose Gender')); ?>" required value="<?php echo e(old('gender', $medicalRecord->patient->gender)); ?>">
        <option value="male"><?php echo e(__('Male')); ?></option>
        <option value="female"><?php echo e(__('Female')); ?></option>
    </select>
</div>
<?php
    $fields = [
        'nik' => 'NIK',
        'place_of_birth' => 'Place Of Birth',
        'birthdate' => 'Birth Date',
        'dukuh' => 'Dukuh',
        'rt' => 'RT',
        'rw' => 'RW',
    ];
?>

<?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="w-full">
        <?php if (isset($component)) { $__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-label','data' => ['for' => ''.e($field).'','value' => __($label)]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => ''.e($field).'','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__($label))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581)): ?>
<?php $attributes = $__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581; ?>
<?php unset($__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581)): ?>
<?php $component = $__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581; ?>
<?php unset($__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal18c21970322f9e5c938bc954620c12bb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal18c21970322f9e5c938bc954620c12bb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.text-input','data' => ['id' => ''.e($field).'','name' => ''.e($field).'','type' => ''.e(in_array($field, ['rt', 'rw']) ? 'number' : ($field == 'birth_date' ? 'date' : 'text')).'','class' => 'mt-1 block w-full','value' => ''.e(old($field, $medicalRecord->patient->$field)).'','placeholder' => ''.e(__($label)).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => ''.e($field).'','name' => ''.e($field).'','type' => ''.e(in_array($field, ['rt', 'rw']) ? 'number' : ($field == 'birth_date' ? 'date' : 'text')).'','class' => 'mt-1 block w-full','value' => ''.e(old($field, $medicalRecord->patient->$field)).'','placeholder' => ''.e(__($label)).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal18c21970322f9e5c938bc954620c12bb)): ?>
<?php $attributes = $__attributesOriginal18c21970322f9e5c938bc954620c12bb; ?>
<?php unset($__attributesOriginal18c21970322f9e5c938bc954620c12bb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal18c21970322f9e5c938bc954620c12bb)): ?>
<?php $component = $__componentOriginal18c21970322f9e5c938bc954620c12bb; ?>
<?php unset($__componentOriginal18c21970322f9e5c938bc954620c12bb); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->createReport->get($field),'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->createReport->get($field)),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php if (! $__env->hasRenderedOnce('0723a824-655d-4bf7-a3d1-884505d81dee')): $__env->markAsRenderedOnce('0723a824-655d-4bf7-a3d1-884505d81dee');
$__env->startPush('scripts'); ?>
    <script src="/js/tom-select.js" defer></script>
    <script>
        window.addEventListener('DOMContentLoaded', (event) => {
            initTomSelect();
        });

        function initTomSelect() {
            const tomSelect = new TomSelect('#select-patient', {
                valueField: 'name',
                labelField: 'name',
                searchField: 'name',
                placeholder: '<?php echo e(__('Search patient...')); ?>',
                create: true,
                multiple: false,
                load: function(query, callback) {
                    var url = '<?php echo e(route('api.patients')); ?>?name=' + encodeURIComponent(query);
                    fetch(url, {
                            headers: {
                                'Accept': 'application/json',
                                'Content-Type': 'application/json',
                                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]')
                                    .getAttribute('content')
                            }
                        })
                        .then(response => {
                            if (!response.ok) {
                                throw new Error('Network response was not ok');
                            }
                            return response.json();
                        })
                        .then(json => {
                            if (Array.isArray(json)) {
                                callback(json);
                            } else {
                                console.error('Expected an array but got:', json);
                                callback();
                            }
                        })
                        .catch(error => {
                            console.error('Fetch error:', error);
                            callback();
                        });
                },
                render: {
                    option: function(item, escape) {
                        const genderClass = escape(item.gender) === 'male' ? 'bg-blue-500' : 'bg-pink-500';
                        const genderText = escape(item.gender) === 'male' ? "L" : "P";
                        const unknownText = '<?php echo e(__('Unknown')); ?>';

                        const place = item.place_of_birth || unknownText;
                        const date = item.birthdate || unknownText;

                        return `<div class="py-2 flex flex-col">
                                    <p class="h5">
                                        ${escape(item.name)} 
                                        <span class="${genderClass} text-white text-xs rounded-full px-2">${genderText}</span>
                                    </p>
                                    <div class="text-xs text-gray-500 grid grid-cols-5">
                                        <div class="col-span-1">NIK</div> 
                                        <div class="col-span-4">: ${escape(item.nik) || unknownText}</div>
                                        <div class="col-span-1">Alamat</div> 
                                        <div class="col-span-4">: ${escape(item.address) || unknownText}</div>
                                        <div class="col-span-1">TTL</div> 
                                        <div class="col-span-4">: ${escape(item.place_of_birth) || unknownText} - ${escape(item.birthdate) || unknownText}</div>
                                    </div>
                                </div>`;
                    },
                    item: function(selectedItem, escape) {
                        document.getElementById('nik').value = selectedItem.nik || '';
                        document.getElementById('gender').value = selectedItem.gender || '';
                        document.getElementById('place_of_birth').value = selectedItem.place_of_birth || '';
                        document.getElementById('birthdate').value = selectedItem.birthdate || '';
                        document.getElementById('dukuh').value = selectedItem.dukuh || '';
                        document.getElementById('rt').value = selectedItem.rt || '';
                        document.getElementById('rw').value = selectedItem.rw || '';

                        return `<div>${escape(selectedItem.name)}</div>`
                    }
                }
            });
            tomSelect.addOption({
                name: '<?php echo e($medicalRecord->patient->name); ?>',
                nik: '<?php echo e($medicalRecord->patient->nik); ?>',
                nik: '<?php echo e($medicalRecord->patient->nik); ?>',
                gender: '<?php echo e($medicalRecord->patient->gender); ?>',
                place_of_birth: '<?php echo e($medicalRecord->patient->place_of_birth); ?>',
                birthdate: '<?php echo e($medicalRecord->patient->birthdate); ?>',
                dukuh: '<?php echo e($medicalRecord->patient->dukuh); ?>',
                rt: '<?php echo e($medicalRecord->patient->rt); ?>',
                rw: '<?php echo e($medicalRecord->patient->rw); ?>',
            });
            tomSelect.addItem('<?php echo e($medicalRecord->patient->name); ?>');
        }
    </script>
<?php $__env->stopPush(); endif; ?>
<?php /**PATH /home/xirf/00.Projects/02.PHP/posyandu/resources/views/posyandu/partials/edit/patient.blade.php ENDPATH**/ ?>