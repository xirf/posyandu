<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-2xl text-gray-800 leading-tight">
            <?php echo e(__('Add Activity')); ?>

        </h2>
        <p>
            <?php echo e(__('Add new actvity, and share it with the world.')); ?>

        </p>
     <?php $__env->endSlot(); ?>

    <form action="<?php echo e($submit_to); ?>" id="activity-form" method="POST" x-data="{
        medias: <?php echo e(old('medias', '[]')); ?>,
        y_availableImages: [],
        y_selectedImage: <?php echo e(old('medias', '[]')); ?>,
        y_isImageLoading: true,
        y_endpoint: '<?php echo e(route('upload')); ?>',
        y_csrf: '<?php echo e(csrf_token()); ?>',
    
        y_selectLocalImage() {
            const input = document.createElement('input');
            input.type = 'file';
            input.accept = 'image/jpg,image/png,image/svg,image/jpeg,image/webp';
            input.click();
    
            input.onchange = () => {
                const file = input.files[0];
                if (file) this.y_saveToServer(file);
            };
        },
    
        y_saveToServer(file) {
            const fd = new FormData();
            fd.append('image', file);
            fetch(this.y_endpoint, {
                    method: 'POST',
                    headers: { 'X-CSRF-Token': this.y_csrf },
                    body: fd
                })
                .then(response => response.json())
                .then(data => {
                    this.y_img = data.url
                    console.log(data.url);
                    console.log(this.medias);
                    this.medias.push(data.url);
                    $dispatch('close-modal', 'add-medias-modal');
                    console.log(this.medias);
                })
                .catch(error => console.error(error));
        },
    
        y_insertSelectedImage() {
            if (this.y_selectedImage) {
                this.y_img = this.y_selectedImage;
                console.log(this.medias);
                this.medias.push(this.y_selectedImage);
                $dispatch('close-modal', 'add-medias-modal');
                console.log(JSON.stringify(this.medias));
                $dispatch('close-modal', 'add-medias-modal');
            }
        },
    
        fetchImages() {
            this.y_isImageLoading = true;
            fetch('<?php echo e(route('get.images')); ?>')
                .then(response => response.json())
                .then(images => this.y_availableImages = images)
                .catch(error => console.error(error))
                .finally(() => this.y_isImageLoading = false);
        }
    }">
        <?php echo csrf_field(); ?>
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 flex gap-8  items-start">
            <div class="grow space-y-4">
                <div class="p-4 bg-white shadow sm:rounded-lg space-y-4" x-data="{ permalink: '<?php echo e(old('slug')); ?>', overflow: false, sitePath: '<?php echo e(url('activity')); ?>' }">
                    <?php if (isset($component)) { $__componentOriginal18c21970322f9e5c938bc954620c12bb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal18c21970322f9e5c938bc954620c12bb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.text-input','data' => ['class' => 'w-full','placeholder' => ''.e(__('Title')).'','name' => 'title','id' => 'title','value' => ''.e(old('title')).'','required' => true,'autofocus' => true,'@input' => ' permalink = sitePath + \'/\' + $event.target.value.trim().toLowerCase().replace(/ /g, \'-\').replace(/[^\w-]/g, \'\').substring(0, 100);
                                 overflow = $event.target.value.length > 60']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-full','placeholder' => ''.e(__('Title')).'','name' => 'title','id' => 'title','value' => ''.e(old('title')).'','required' => true,'autofocus' => true,'@input' => ' permalink = sitePath + \'/\' + $event.target.value.trim().toLowerCase().replace(/ /g, \'-\').replace(/[^\w-]/g, \'\').substring(0, 100);
                                 overflow = $event.target.value.length > 60']); ?>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal18c21970322f9e5c938bc954620c12bb)): ?>
<?php $attributes = $__attributesOriginal18c21970322f9e5c938bc954620c12bb; ?>
<?php unset($__attributesOriginal18c21970322f9e5c938bc954620c12bb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal18c21970322f9e5c938bc954620c12bb)): ?>
<?php $component = $__componentOriginal18c21970322f9e5c938bc954620c12bb; ?>
<?php unset($__componentOriginal18c21970322f9e5c938bc954620c12bb); ?>
<?php endif; ?>
                    <p x-show="overflow" class="text-orange-500 text-xs">
                        <?php echo e(__('It\'s not recommended to use more than 60 characters for the title')); ?>

                    </p>
                    <div class="text-sm text-gray-500">
                        <p>
                            <?php echo e(__('Permalink: ')); ?> <span x-text="permalink"></span>
                        </p>
                        <input type="text" name="permalink" id="permalink" :value="permalink"
                            class="border border-gray-300 rounded-md w-full hidden" readonly>
                    </div>

                    <?php if(old('about')): ?>
                        <div class="hidden" id="quill-initial-data">
                            <?php echo old('about', null); ?>

                        </div>
                    <?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal96da531b6fa4e15e5fd869b0609495d2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal96da531b6fa4e15e5fd869b0609495d2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.quill','data' => ['name' => 'about','placeholder' => 'Content here...','endpoint' => `<?php echo e(route('upload')); ?>`,'formId' => 'activity-form']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('quill'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'about','placeholder' => 'Content here...','endpoint' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(`{{ route('upload') }}`),'formId' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('activity-form')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal96da531b6fa4e15e5fd869b0609495d2)): ?>
<?php $attributes = $__attributesOriginal96da531b6fa4e15e5fd869b0609495d2; ?>
<?php unset($__attributesOriginal96da531b6fa4e15e5fd869b0609495d2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal96da531b6fa4e15e5fd869b0609495d2)): ?>
<?php $component = $__componentOriginal96da531b6fa4e15e5fd869b0609495d2; ?>
<?php unset($__componentOriginal96da531b6fa4e15e5fd869b0609495d2); ?>
<?php endif; ?>
                </div>
                <div class="p-4 bg-white shadow sm:rounded-lg space-y-4"">
                    <div>
                        <h2 class="block mb-1 text-lg font-semibold text-gray-700"><?php echo e(__('Documentation')); ?></h2>
                        <p class="text-xs text-gray"><?php echo e(__('Add a photo of the activity here ')); ?></p>
                        <input type="text" class="hidden" name="medias" :value="JSON.stringify(medias)">
                    </div>
                    <div class="flex flex-wrap gap-4">
                        <template x-for="(media, index) in medias" :key="index">
                            <div class="relative border">
                                <img :src="media" class="w-32 h-32 object-cover rounded-lg" alt="media">
                                <button type="button" @click="medias.splice(index, 1)"
                                    class="absolute top-2 right-2 p-1 bg-white rounded-full">
                                    <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('heroicon-o-trash'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\BladeUI\Icons\Components\Svg::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-5 h-5 text-red-500']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
                                </button>
                            </div>
                        </template>
                        <?php echo $__env->make('activity.partials.uploadfile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
            </div>

            <div class="w-full max-w-md space-y-4">
                <?php echo $__env->make('activity.partials.sidebar', ['tags' => $tags], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </form>


    <?php if($errors): $__env->startPush( 'scripts'); ?>
    <script>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            notyf.error('<?php echo e($error); ?>');
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </script>
    <?php $__env->stopPush(); endif; ?>
    <?php if(session('success')): $__env->startPush( 'scripts'); ?>
    <script>
        notyf.success('<?php echo e(session('success')); ?>');
    </script>
    <?php $__env->stopPush(); endif; ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /home/xirf/00.Projects/02.PHP/posyandu/resources/views/activity/new.blade.php ENDPATH**/ ?>