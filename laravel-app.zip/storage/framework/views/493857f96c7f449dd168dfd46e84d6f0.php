<?php if (isset($component)) { $__componentOriginal74bf5c5ceb04ec08d68cbab7bf77439b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal74bf5c5ceb04ec08d68cbab7bf77439b = $attributes; } ?>
<?php $component = App\View\Components\HomeLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('home-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\HomeLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="w-full max-w-6xl mx-auto space-y-12 py-14 p-8 flex justify-center" x-data="{
        selected: '<?php echo e($activity->thumbnail); ?>',
        openModal() {
            $dispatch('open-modal', 'open-detail-modal')
        },
        close() {
            $dispatch('close-modal', 'open-detail-modal')
        }
    }">
        <div class="flex flex-col gap-4 max-w-3xl w-full">
            <h1 class="text-4xl font-black leading-relaxed "><?php echo e($activity->title); ?></h1>
            <div class="inline-flex items-center gap-4 border-b pb-4 flex-wrap">
                <img src="<?php echo e($activity->user->picture); ?>" alt="<?php echo e($activity->user->name); ?>"
                    class="h-6 w-6 object-cover rounded-full">
                <div class="text-gray-500 text-sm"><?php echo e($activity->user->name); ?> &middot;
                    <?php echo e($activity->created_at->diffForHumans()); ?></div>
                &middot;
                <?php $__currentLoopData = $activity->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e($tag->slug); ?>"
                        class="bg-cyan-500/20 text-cyan-700 px-2 py-1 rounded-md text-xs whitespace-nowrap"><?php echo e($tag->name); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div>
                <article class="prose prose-md w-full max-w-none ">
                    <picture class="w-full mx-auto flex items-center justify-center mb-8">
                        <img src="<?php echo e($activity->thumbnail); ?>" alt="<?php echo e($activity->title); ?>"
                            class="max-h-[480px] object-contain rounded-xl border w-fit">
                    </picture>


                    <?php echo $activity->render(); ?>



                    <h2 class="w-full border-b">Dokumentasi</h2>
                    <div class="not-prose grid grid-cols-3 md:grid-cols-4 gap-4">
                        <?php if(empty($activity->medias)): ?>
                            <div class="w-full flex items-center justify-center gap-4">

                            </div>
                        <?php else: ?>
                            <?php $__currentLoopData = json_decode($activity->medias); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <img src="<?php echo e($media); ?>" alt=""
                                    @click="selected = '<?php echo e($media); ?>'; openModal()"
                                    class="w-full h-full object-contain rounded-xl border cursor-pointer">
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                </article>
            </div>
        </div>
        <?php if (isset($component)) { $__componentOriginal9f64f32e90b9102968f2bc548315018c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9f64f32e90b9102968f2bc548315018c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['name' => 'open-detail-modal','xShow' => 'openModal','@close' => 'close']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'open-detail-modal','x-show' => 'openModal','@close' => 'close']); ?>
            <img :src="selected" alt="" class="w-full h-full object-contain rounded-xl border">
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $attributes = $__attributesOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__attributesOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $component = $__componentOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__componentOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
    </div>
    <div class="pt-8 mt-8 border-t flex flex-col gap-4 max-w-7xl mx-auto p-8">

        <h1 class="text-3xl font-black">Mungkin Anda Juga Suka</h1>
        <?php if($recommendations->count() == 0): ?>
            <div class="w-full flex justify-center" style="box-shadow: 10px 40px 50px 0 #e5f6f56b">
                <?php if (isset($component)) { $__componentOriginal81e6c9cd0e7e35c2f65e797087f6daca = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal81e6c9cd0e7e35c2f65e797087f6daca = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.guest.empty','data' => ['header' => 'Tidak Ada Aktivitas Lainnya','message' => 'Sepertinya kami perlukan waktu untuk menyiapkan aktivitas terbaru. Silahkan kembali lagi nanti.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest.empty'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['header' => 'Tidak Ada Aktivitas Lainnya','message' => 'Sepertinya kami perlukan waktu untuk menyiapkan aktivitas terbaru. Silahkan kembali lagi nanti.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal81e6c9cd0e7e35c2f65e797087f6daca)): ?>
<?php $attributes = $__attributesOriginal81e6c9cd0e7e35c2f65e797087f6daca; ?>
<?php unset($__attributesOriginal81e6c9cd0e7e35c2f65e797087f6daca); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal81e6c9cd0e7e35c2f65e797087f6daca)): ?>
<?php $component = $__componentOriginal81e6c9cd0e7e35c2f65e797087f6daca; ?>
<?php unset($__componentOriginal81e6c9cd0e7e35c2f65e797087f6daca); ?>
<?php endif; ?>
            </div>
        <?php else: ?>
            <div class="flex items-center justify-start gap-4 flex-col">
                <?php $__currentLoopData = $recommendations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="bg-white shadow-cyan-200 rounded-xl overflow-hidden border border-gray-100 relative z-10"
                        style="box-shadow: 10px 40px 50px 0 #e5f6f56b">
                        <a href="<?php echo e(route('activity.show', $item['slug'])); ?>"
                            class="w-full flex flex-col-reverse md:flex-row">
                            <div class="p-8 flex flex-col gap-3 shrink">
                                <h2 class="text-xl font-bold leading-relaxed line-clamp-2"><?php echo e($item['title']); ?>

                                </h2>
                                <p><?php echo e($item->getDiff()); ?></p>
                                <p class="leading-normal text-sm text-gray-400"><?php echo e($item->getExcerpt(200)); ?></p>
                                <p class="text-cyan-500">
                                    Baca Selengkapnya...
                                </p>
                            </div>
                            <div
                                class="w-full md:w-56 lg:w-96 shrink-0 h-auto aspect-video flex items-center justify-center relative bg-white object-cover">
                                <img src="<?php echo e($item['thumbnail']); ?>" alt=""
                                    class="w-full h-full object-cover aspect-video">
                            </div>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal74bf5c5ceb04ec08d68cbab7bf77439b)): ?>
<?php $attributes = $__attributesOriginal74bf5c5ceb04ec08d68cbab7bf77439b; ?>
<?php unset($__attributesOriginal74bf5c5ceb04ec08d68cbab7bf77439b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal74bf5c5ceb04ec08d68cbab7bf77439b)): ?>
<?php $component = $__componentOriginal74bf5c5ceb04ec08d68cbab7bf77439b; ?>
<?php unset($__componentOriginal74bf5c5ceb04ec08d68cbab7bf77439b); ?>
<?php endif; ?>
<?php /**PATH /home/xirf/00.Projects/02.PHP/posyandu/resources/views/activity/show.blade.php ENDPATH**/ ?>