<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-2xl text-gray-800 leading-tight">
            <?php echo e(__('Add News')); ?>

        </h2>
        <p>
            <?php echo e(__('Add new news, and share it with the world.')); ?>

        </p>
     <?php $__env->endSlot(); ?>

    <form action="<?php echo e($submit_to); ?>" id="news-form" method="POST">
        <?php echo csrf_field(); ?>
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 flex flex-col xl:flex-row p-4 gap-8  items-start">
            <div class="grow space-y-4">
                <div class="p-4 bg-white shadow sm:rounded-lg space-y-4" x-data="{ permalink: '<?php echo e(old('permalink', url('news'))); ?>', overflow: false, sitePath: '<?php echo e(url('news')); ?>' }">
                    <?php if (isset($component)) { $__componentOriginal18c21970322f9e5c938bc954620c12bb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal18c21970322f9e5c938bc954620c12bb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.text-input','data' => ['class' => 'w-full','placeholder' => ''.e(__('Title')).'','name' => 'title','id' => 'title','value' => ''.e(old('title')).'','required' => true,'autofocus' => true,'@input' => ' permalink = sitePath + \'/\' + $event.target.value.trim().toLowerCase().replace(/ /g, \'-\').replace(/[^\w-]/g, \'\').substring(0, 100);
                                 overflow = $event.target.value.length > 60']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-full','placeholder' => ''.e(__('Title')).'','name' => 'title','id' => 'title','value' => ''.e(old('title')).'','required' => true,'autofocus' => true,'@input' => ' permalink = sitePath + \'/\' + $event.target.value.trim().toLowerCase().replace(/ /g, \'-\').replace(/[^\w-]/g, \'\').substring(0, 100);
                                 overflow = $event.target.value.length > 60']); ?>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal18c21970322f9e5c938bc954620c12bb)): ?>
<?php $attributes = $__attributesOriginal18c21970322f9e5c938bc954620c12bb; ?>
<?php unset($__attributesOriginal18c21970322f9e5c938bc954620c12bb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal18c21970322f9e5c938bc954620c12bb)): ?>
<?php $component = $__componentOriginal18c21970322f9e5c938bc954620c12bb; ?>
<?php unset($__componentOriginal18c21970322f9e5c938bc954620c12bb); ?>
<?php endif; ?>
                    <div class="text-sm text-gray-500">
                        <p>
                            <?php echo e(__('Permalink: ')); ?> <span x-text="permalink"></span>
                        </p>
                        <input type="text" name="permalink" id="permalink" :value="permalink"
                            class="border border-gray-300 rounded-md w-full hidden" readonly>
                    </div>

                    <?php if(old('about')): ?>
                        <div class="hidden" id="quill-initial-data">
                            <?php echo old('about', null); ?>

                        </div>
                    <?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal96da531b6fa4e15e5fd869b0609495d2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal96da531b6fa4e15e5fd869b0609495d2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.quill','data' => ['name' => 'about','placeholder' => ''.e(__('Content here...')).'','endpoint' => `<?php echo e(route('upload')); ?>`,'formId' => 'news-form']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('quill'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'about','placeholder' => ''.e(__('Content here...')).'','endpoint' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(`{{ route('upload') }}`),'formId' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('news-form')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal96da531b6fa4e15e5fd869b0609495d2)): ?>
<?php $attributes = $__attributesOriginal96da531b6fa4e15e5fd869b0609495d2; ?>
<?php unset($__attributesOriginal96da531b6fa4e15e5fd869b0609495d2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal96da531b6fa4e15e5fd869b0609495d2)): ?>
<?php $component = $__componentOriginal96da531b6fa4e15e5fd869b0609495d2; ?>
<?php unset($__componentOriginal96da531b6fa4e15e5fd869b0609495d2); ?>
<?php endif; ?>
                </div>
            </div>

            <div class="w-full max-w-md space-y-4">
                <?php echo $__env->make('news.partials.sidebar', ['tags' => $tags], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </form>


    <?php if($errors): $__env->startPush( 'scripts'); ?>
    <script>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            notyf.error('<?php echo e($error); ?>');
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </script>
    <?php $__env->stopPush(); endif; ?>
    <?php if(session('success')): $__env->startPush( 'scripts'); ?>
    <script>
        notyf.success('<?php echo e(session('success')); ?>');
    </script>
    <?php $__env->stopPush(); endif; ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /home/xirf/00.Projects/02.PHP/posyandu/resources/views/news/new.blade.php ENDPATH**/ ?>