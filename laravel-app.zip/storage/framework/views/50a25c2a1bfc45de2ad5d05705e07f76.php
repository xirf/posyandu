
<?php
    $menus = [
        ['all', __('All')],
        ['infant', __('Infant')],
        ['child', __('Child')],
        ['teenager', __('Teenager')],
        ['adult', __('Adult')],
        ['elderly', __('Elderly')],
    ];
?>

<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="max-w-full sm:p-6 lg:p-8 bg-white shadow h-screen" x-data="{
        activeData: [],
        isOpen: false,
        modelOpen: false,
        openedIndex: 0,
        openedWithKeyboard: false,
        selected: '<?php echo e($menus[0][0]); ?>',
        selectedPatient: null,
        ages: {
            'all': '<?php echo e(__('All')); ?>',
            'infant': '<?php echo e(__('Infant')); ?>',
            'child': '<?php echo e(__('Child')); ?>',
            'teenager': '<?php echo e(__('Teenager')); ?>',
            'adult': '<?php echo e(__('Adult')); ?>',
            'elderly': '<?php echo e(__('Elderly')); ?>',
        },
        isLoading: true,
        sortBy: null,
        async getTable(ageGroup = 'all', link = null) {
            this.isLoading = true;
            try {
                let endpoint = link ? link : '<?php echo e(route('posyandu.table')); ?>';
                let params = { ageGroup };
                let response = await axios.get(endpoint, {
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    params
                });
                this.activeData = response.data;
            } catch (error) {
                console.error(error);
            } finally {
                this.isLoading = false;
            }
        },
        init() {
            this.getTable();
        },
        sortBy(column) {
            const getNestedValue = (obj, path) => path.split('.').reduce((acc, part) => acc && acc[part], obj);
            if (this.activeData.sortBy === column) {
                this.activeData.data.reverse();
                return;
            }
            if (typeof getNestedValue(this.activeData.data[0], column) === 'number') {
                this.activeData.data.sort((a, b) => getNestedValue(a, column) - getNestedValue(b, column));
            } else {
                this.activeData.data.sort((a, b) => getNestedValue(a, column).localeCompare(getNestedValue(b, column)));
            }
    
            this.activeData.sortBy = column;
        },
        async search(keyword) {
            this.isLoading = true;
            try {
                let response = await axios.get('<?php echo e(route('posyandu.table.search')); ?>', {
                    params: { search: keyword },
                    headers: {
                        'Content-Type': 'application/json',
                    }
                });
                this.activeData = response.data;
            } catch (error) {
                console.error(error);
            } finally {
                this.isLoading = false;
            }
        }
    }">
        <div class="w-full grow flex flex-col h-full space-y-2 p-4">
            <div class="w-full grid md:flex grid-cols-3 md:flex-row z-50 flex-end gap-4">
                <div class="grow col-span-3">
                    <h2 class="text-lg font-semibold text-neutral-900 dark:text-neutral-200"><?php echo e(__('Posyandu')); ?></h2>
                    <p class="text-xs font-normal text-neutral-500 dark:text-neutral-400">
                        <?php echo e(__('Click name to see more')); ?></p>
                </div>
                <div class="col-span-3 md:max-w-36">
                    <?php echo $__env->make('posyandu.partials.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="grid grid-cols-3 md:w-80 gap-4 col-span-3">
                    <?php echo $__env->make('posyandu.partials.age-filter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo $__env->make('posyandu.partials.export', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <a href="<?php echo e(route('dashboard.posyandu.create')); ?>" class="w-full">
                        <?php if (isset($component)) { $__componentOriginald411d1792bd6cc877d687758b753742c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald411d1792bd6cc877d687758b753742c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-button','data' => ['class' => 'w-full']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('primary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-full']); ?> <?php echo e(__('Add')); ?>  <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $attributes = $__attributesOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__attributesOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $component = $__componentOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__componentOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
                    </a>
                </div>
            </div>
            <div class="w-full overflow-auto grow border rounded-md h-full">
                <?php echo $__env->make('posyandu.partials.table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <?php echo $__env->make('posyandu.partials.pagination', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <?php echo $__env->make('posyandu.partials.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <?php if(session('success')): ?>
        <?php $__env->startPush('scripts'); ?>
            <script>
                notyf.success('<?php echo e(session('success')); ?>');
            </script>
        <?php $__env->stopPush(); ?>
    <?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /home/xirf/00.Projects/02.PHP/posyandu/resources/views/posyandu/all.blade.php ENDPATH**/ ?>