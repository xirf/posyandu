<div class="relative bg-primary text-white w-full mt-20">
    <div class="grid p-8 md:grid-cols-2 lg:grid-cols-3 max-w-7xl w-full mx-auto py-12 relative gap-y-10">
        <div class="flex flex-col gap-4">
            <h1 class="text-3xl font-black"> <?php echo e($siteInfo->name ?? config('app.name', 'Posyandu Bareng')); ?> </h1>
            <p>
                <?php echo e($siteInfo->address ?? ' Desa Bareng, Kecamatan Pudak, Kabupaten Ponorogo, Jawa Timur, 63418 '); ?>

            </p>
            <p class="text-xs">Didukung oleh: KKN Tematika UMPO 2024</p>
        </div>

        <div class="hidden lg:block">

        </div>

        <div class="grid gap-4 h-fit">
            <h1 class="text-3xl font-black"> Hubungi Kami </h1>

            <div class="flex flex-col gap-1">
                <?php if($siteInfo->phone): ?>
                    <a href="tel:<?php echo e(preg_replace('/\D/', '', $siteInfo->phone)); ?>">
                        <p> <?php echo e($siteInfo->phone); ?> </p>
                    </a>
                <?php endif; ?>

                <?php if($siteInfo->email): ?>
                    <a href="mailto:<?php echo e($siteInfo->email); ?>">
                        <p> <?php echo e($siteInfo->email); ?> </p>
                    </a>
                <?php endif; ?>
            </div>
            <br />
            <h1 class="text-3xl font-black">Tenaga Kesehatan</h1>
            <a href="<?php echo e(route('login')); ?>">
                <?php if (isset($component)) { $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.secondary-button','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('secondary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                    <?php echo e(__('Login')); ?>

                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $attributes = $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $component = $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
            </a>
        </div>
        <img src="/images/grids.svg" alt="" class="absolute -top-16 -right-24 h-32 w-32">
    </div>
</div>
<?php /**PATH /home/xirf/00.Projects/02.PHP/posyandu/resources/views/components/footer.blade.php ENDPATH**/ ?>