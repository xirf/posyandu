<?php if (! $__env->hasRenderedOnce('82097155-dfe9-499c-a8ea-fac1a398a46d')): $__env->markAsRenderedOnce('82097155-dfe9-499c-a8ea-fac1a398a46d');
$__env->startPush('styles'); ?>
    <style>
        thead > tr > th:first-child, tbody > tr > td:first-child{
            background-color: white !important;
        }
    </style>
<?php $__env->stopPush(); endif; ?>
<table class="table">
    <thead class="bg-[#f5f7f9]">
        <tr>
            <th @click="sortBy('patient.name')" class="w-30 cursor-pointer bg-red-300"><span><?php echo e(__('Patient')); ?></span></th>
            <th @click="sortBy('patient.dukuh')" class="w-30 cursor-pointer"><span><?php echo e(__('Address')); ?></span></th>
            <th @click="sortBy('patient.age_group')" class="w-30 cursor-pointer"><span><?php echo e(__('Age Group')); ?></span></th>
            <th @click="sortBy('vital_statistics.height')" class="w-20 cursor-pointer"><span class="tooltip tooltip-bottom" data-tip="<?php echo e(__('Height')); ?>"><?php echo e(__('TB')); ?></span> </th>
            <th @click="sortBy('vital_statistics.weight')" class="w-20 cursor-pointer"><span class="tooltip tooltip-bottom" data-tip="<?php echo e(__('Weight')); ?>"><?php echo e(__('BB')); ?></span> </th>
            <th @click="sortBy('vital_statistics.head_circumference')" class="w-20 cursor-pointer"><span class="tooltip tooltip-bottom" data-tip="<?php echo e(__('Head Circumference')); ?>"><?php echo e(__('LK')); ?></span> </th>
            <th @click="sortBy('vital_statistics.arm_circumference')" class="w-20 cursor-pointer"><span class="tooltip tooltip-bottom" data-tip="<?php echo e(__('Upper Arm Circumference')); ?>"><?php echo e(__('LILA')); ?></span></th>
            <th @click="sortBy('patient.name')" class="w-20 cursor-pointer"><span class="tooltip tooltip-bottom" data-tip="<?php echo e(__('Abdominal Circumference')); ?>"><?php echo e(__('LP')); ?></span></th>
            <th x-show="openedIndex > 2 || openedIndex == 0" @click="sortBy('lab_results.cholesterol')" class="w-20 cursor-pointer"> <span><?php echo e(__('Cholesterol')); ?></span> </th>
            <th x-show="openedIndex > 2 || openedIndex == 0" @click="sortBy('lab_results.hemoglobin')" class="w-20 cursor-pointer"><span class="tooltip tooltip-bottom" data-tip="<?php echo e(__('Hemoglobin')); ?>"><?php echo e(__('HB')); ?></span></th>
            <th x-show="openedIndex > 2 || openedIndex == 0" @click="sortBy('lab_results.gda')" class="w-20 cursor-pointer"><span class="tooltip tooltip-bottom" data-tip="<?php echo e(__('Glucose Level')); ?>"><?php echo e(__('GDA')); ?></span></th>
            <th x-show="openedIndex > 2 || openedIndex == 0" @click="sortBy('lab_results.ua')" class="w-48 cursor-pointer"><span class="tooltip tooltip-bottom" data-tip="<?php echo e(__('Urine Test')); ?>"><?php echo e(__('UA')); ?></span></th>
            <th x-show="openedIndex > 3 || openedIndex == 0" @click="sortBy('family_planning')" class="w-20 cursor-pointer"><span class="tooltip tooltip-bottom" data-tip="<?php echo e(__('Family Planning')); ?>"><?php echo e(__('KB')); ?></span></th>
            <th x-show="openedIndex > 3 || openedIndex == 0" @click="sortBy('complaints')" class="w-48 cursor-pointer"><span><?php echo e(__('Complaints')); ?></span></th>
            <th x-show="openedIndex > 3 || openedIndex == 0" @click="sortBy('diagnosis')" class="w-48 cursor-pointer"><span><?php echo e(__('Diagnosic')); ?></span></th>
            <th x-show="openedIndex > 3 || openedIndex == 0" @click="sortBy('diseases')" class="w-48 cursor-pointer"><span><?php echo e(__('Disease')); ?></span></th>
            <th x-show="openedIndex > 3 || openedIndex == 0" @click="sortBy('medication')" class="w-48 cursor-pointer"><span><?php echo e(__('Medication')); ?></span></th>
    </thead>
    <tbody>
        <template x-for="data in activeData.data" :key="data.id">
            <tr class="hover:bg-cyan-50" x-show="!isLoading && !data.hiddenBySearch"
            @click="modelOpen=true; selectedPatient=data"
            >
                <td class="bg-red-500"> <div class="grid bg-red-500!" > <div :class="{ 'text-blue-500': data.patient.gender === 'male', 'text-pink-500': data.patient.gender === 'female', }" class="font-bold w-32 truncate text-sm" x-text="data.patient.name"></div> </div> <div x-text="`${data.patient.place_of_birth} ${data.patient.birthdate}`"></div> </div> </td>
                <td> <div class="grid"> <div x-text="data.patient.dukuh"></div> <div class="text-gray-400" x-text="`RT ${data.patient.rt}`"></div> <div class="text-gray-400" x-text="`RW ${data.patient.rw}`"></div> </div> </td>
                <td x-text="ages[data.patient.age_group]"></td>
                <td x-text="data.vital_statistics.height"></td>
                <td x-text="data.vital_statistics.weight"></td>
                <td x-text="data.vital_statistics.head_circumference"></td>
                <td x-text="data.vital_statistics.arm_circumference"></td>
                <td x-text="data.vital_statistics.abdominal_circumference"></td>
                <td x-show="openedIndex > 2 || openedIndex == 0" x-text="data.lab_results?.cholesterol"></td>
                <td x-show="openedIndex > 2 || openedIndex == 0" x-text="data.lab_results?.hemoglobin"></td>
                <td x-show="openedIndex > 2 || openedIndex == 0" x-text="data.lab_results?.gda"></td>
                <td x-show="openedIndex > 2 || openedIndex == 0" > <div x-text="data.lab_results?.ua" class="line-clamp-4"></div></td>
                <td x-show="openedIndex > 3 || openedIndex == 0" > <div x-text="data.family_planning ==  0 ? '<?php echo e(__('No')); ?>' : '<?php echo e(__('Yes')); ?>'" :class="{ 'badge-success': data.family_planning == 1, 'badge-neutral': data.family_planning == 0 }" class="badge badge-outline"> </div> </td>
                <td x-show="openedIndex > 3 || openedIndex == 0" > <div x-text="data.complaints" class="line-clamp-4"></div> </td> 
                <td x-show="openedIndex > 3 || openedIndex == 0" > <div x-text="data.diagnosis" class="line-clamp-4"></div> </td>
                <td x-show="openedIndex > 3 || openedIndex == 0" > <div x-text="data.diseases" class="line-clamp-4"></div> </td>
                <td x-show="openedIndex > 3 || openedIndex == 0" > <div x-text="data.medication" class="line-clamp-4"></div> </td>
            </tr>
        </template>

        <tr x-show="isLoading">
            <td colspan="15" class="text-center h-32">
                <div class="loading loading-spinner loading-lg"></div>
            </td>
        </tr>

        <tr x-show="!isLoading && activeData.length === 0">
            <td colspan="15" class="text-center">
                <?php if (isset($component)) { $__componentOriginal4f22a152e0729cd34293e65bd200d933 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4f22a152e0729cd34293e65bd200d933 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.empty','data' => ['text' => __('No data available'),'description' => __('Try changing your filters to see the Patients')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('empty'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['text' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('No data available')),'description' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Try changing your filters to see the Patients'))]); ?>
                     <?php $__env->slot('button', null, []); ?> 
                        <?php if (isset($component)) { $__componentOriginald411d1792bd6cc877d687758b753742c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald411d1792bd6cc877d687758b753742c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-button','data' => ['@click' => 'getTable()']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('primary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['@click' => 'getTable()']); ?>
                            <?php echo e(__('Refresh')); ?>

                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $attributes = $__attributesOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__attributesOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $component = $__componentOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__componentOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
                     <?php $__env->endSlot(); ?>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4f22a152e0729cd34293e65bd200d933)): ?>
<?php $attributes = $__attributesOriginal4f22a152e0729cd34293e65bd200d933; ?>
<?php unset($__attributesOriginal4f22a152e0729cd34293e65bd200d933); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4f22a152e0729cd34293e65bd200d933)): ?>
<?php $component = $__componentOriginal4f22a152e0729cd34293e65bd200d933; ?>
<?php unset($__componentOriginal4f22a152e0729cd34293e65bd200d933); ?>
<?php endif; ?>
            </td>
        </tr>
    </tbody>
</table>
<?php /**PATH /home/xirf/00.Projects/02.PHP/posyandu/resources/views/posyandu/partials/table.blade.php ENDPATH**/ ?>