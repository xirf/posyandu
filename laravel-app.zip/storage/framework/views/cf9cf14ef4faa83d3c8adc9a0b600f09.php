<div class="">
    <div class="flex flex-col-reverse p-8 lg:grid lg:grid-cols-2 gap-10 lg:gap-32 mx-auto max-w-7xl my-20">
        <div class="grid gap-4 relative z-[2]">
            <h1 class="text-2xl md:text-4xl font-black leading-normal lg:leading-relaxed">Melayani Kesehatan Keluarga,
                Menumbuhkan Generasi Sehat</h1>
            <p class="leading-relaxed max-w-lg text-[#7D7987]">Mendukung kesehatan masyarakat di setiap fase kehidupan,
                mulai dari bayi, balita, remaja, dewasa hingga lansia. Dengan layanan kesehatan yang komprehensif dan
                berkelanjutan,</p>

            <?php if($schedule): ?>
                <?php
                    $formattedDate = Carbon\Carbon::parse($schedule->date)->translatedFormat('d F Y');
                    $formattedTime = Carbon\Carbon::parse($schedule->time)->format('H:i');
                ?>
                <div>
                    <p>Posyandu berikutnya dalam:</p>
                    <div class="grid">
                        <div class="flex gap-2 md:items-end flex-col md:flex-row ">
                            <p class="font-black text-3xl">
                                <span class="text-primary" id="day">00</span> Hari <span class="text-primary"
                                    id="hour">00</span> Jam
                            </p>
                            <div class="flex gap-1 items-center text-[#7D7987]">
                                <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('heroicon-o-map-pin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\BladeUI\Icons\Components\Svg::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-4 h-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?> <span><?php echo e($schedule->location); ?></span>
                            </div>
                        </div>
                        <p class="text-xs text-gray-400"><?php echo e($formattedDate); ?> &middot; <?php echo e($formattedTime); ?> WIB</p>
                    </div>
                </div>
            <?php endif; ?>
        </div>
        <div class="w-full h-auto relative z-0">
            <img src="/images/hero-image.png" alt="" class="z-10 relative">
            <img src="/images/blob.svg" class="absolute w-[772px] h-[623px] -bottom-10 left-0 z-0 scale-125">
        </div>
    </div>
</div>

<?php if($schedule): $__env->startPush( 'scripts'); ?>;
<script>
    let date = '<?php echo e($schedule->date); ?>';
    let hour = '<?php echo e($schedule->time); ?>';

    const dayEl = document.getElementById('day');
    const hourEl = document.getElementById('hour');

    const countDown = () => {
        const now = new Date().getTime();
        const eventDate = new Date(date).getTime();
        const diff = eventDate - now;

        console.log(now, eventDate, diff);

        const days = Math.floor(diff / (1000 * 60 * 60 * 24));
        const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));

        dayEl.textContent = days < 10 ? `0${days}` : days;
        hourEl.textContent = hours < 10 ? `0${hours}` : hours;
    }

    countDown();
</script>
<?php $__env->stopPush(); endif; ?>
<?php /**PATH /home/xirf/00.Projects/02.PHP/posyandu/resources/views/home/partials/hero.blade.php ENDPATH**/ ?>