<?php
    $elementId = $elementId ?? 's_' . Str::random(8);
?>

<?php if (! $__env->hasRenderedOnce('3c3bf8e0-b3b6-4eae-8935-50aa3eddffc6')): $__env->markAsRenderedOnce('3c3bf8e0-b3b6-4eae-8935-50aa3eddffc6');
$__env->startPush('styles'); ?>
    <link href="/css/tom-select.css" rel="stylesheet">
    <script src="/js/tom-select.js"></script>
<?php $__env->stopPush(); endif; ?>

<?php if (! $__env->hasRenderedOnce('df6809f3-f592-41de-af78-63d1e92e7b87')): $__env->markAsRenderedOnce('df6809f3-f592-41de-af78-63d1e92e7b87');
$__env->startPush('scripts'); ?>
    <script>
        new TomSelect("#<?php echo e($elementId); ?>", {
            persist: false,
            createOnBlur: true,
            create: true,
            maxItems: null,
            maxOptions: 100,
            valueField: 'id',
            labelField: 'title',
            searchField: 'title',
            sortField: 'title',
        });
    </script>
<?php $__env->stopPush(); endif; ?>

<div class="mb-5 w-full">
    <?php if($label ?? null): ?>
        <label for="<?php echo e($name); ?>" class="form-label block mb-1 text-lg font-semibold text-gray-700">
            <?php echo e($label); ?>

            <?php if($optional ?? null): ?>
                <span class="text-sm text-gray-500 font-normal">(optional)</span>
            <?php endif; ?>
        </label>
    <?php endif; ?>

    <select class="form-control w-full text-base" placeholder="<?php echo e($placeholder ?? 'Pilih tags'); ?>" multiple="multiple"
        name="<?php echo e($name); ?>[]" id="<?php echo e($elementId); ?>">
        <?php $__currentLoopData = $choices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $choice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($choice['value']); ?>" <?php echo e(in_array($choice['value'], isset($oldValues) ? $oldValues : []) ? 'selected' : ''); ?>>
                <?php echo e($choice['label']); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div><?php /**PATH /home/xirf/00.Projects/02.PHP/posyandu/resources/views/components/multi-select.blade.php ENDPATH**/ ?>