<?php if (isset($component)) { $__componentOriginal74bf5c5ceb04ec08d68cbab7bf77439b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal74bf5c5ceb04ec08d68cbab7bf77439b = $attributes; } ?>
<?php $component = App\View\Components\HomeLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('home-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\HomeLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="w-screen space-y-8 lg:space-y-12 p-8 lg:py-14">
        <?php if($activities->count() == 0): ?>
            <?php if (isset($component)) { $__componentOriginal81e6c9cd0e7e35c2f65e797087f6daca = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal81e6c9cd0e7e35c2f65e797087f6daca = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.guest.empty','data' => ['header' => 'Tidak Ada Aktivitas Lainnya','message' => 'Sepertinya kami perlukan waktu untuk menyiapkan aktivitas terbaru. Silahkan kembali lagi nanti.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest.empty'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['header' => 'Tidak Ada Aktivitas Lainnya','message' => 'Sepertinya kami perlukan waktu untuk menyiapkan aktivitas terbaru. Silahkan kembali lagi nanti.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal81e6c9cd0e7e35c2f65e797087f6daca)): ?>
<?php $attributes = $__attributesOriginal81e6c9cd0e7e35c2f65e797087f6daca; ?>
<?php unset($__attributesOriginal81e6c9cd0e7e35c2f65e797087f6daca); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal81e6c9cd0e7e35c2f65e797087f6daca)): ?>
<?php $component = $__componentOriginal81e6c9cd0e7e35c2f65e797087f6daca; ?>
<?php unset($__componentOriginal81e6c9cd0e7e35c2f65e797087f6daca); ?>
<?php endif; ?>
        <?php else: ?>
            <?php echo $__env->make(activity . partials . hero, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make(activity . partials . related, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal74bf5c5ceb04ec08d68cbab7bf77439b)): ?>
<?php $attributes = $__attributesOriginal74bf5c5ceb04ec08d68cbab7bf77439b; ?>
<?php unset($__attributesOriginal74bf5c5ceb04ec08d68cbab7bf77439b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal74bf5c5ceb04ec08d68cbab7bf77439b)): ?>
<?php $component = $__componentOriginal74bf5c5ceb04ec08d68cbab7bf77439b; ?>
<?php unset($__componentOriginal74bf5c5ceb04ec08d68cbab7bf77439b); ?>
<?php endif; ?>
<?php /**PATH /home/xirf/00.Projects/02.PHP/posyandu/resources/views/activity/view.blade.php ENDPATH**/ ?>