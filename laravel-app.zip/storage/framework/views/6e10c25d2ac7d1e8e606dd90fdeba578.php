<?php
    $menus = [
        ['infant', __('Infant')],
        ['child', __('Child')],
        ['teenager', __('Teenager')],
        ['adult', __('Adult')],
        ['elderly', __('Elderly')],
    ];
?>

<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Add New Record')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    <form class="bg-white max-w-7xl mx-auto rounded-lg m-4 border shadow p-4 lg:p-8 space-y-4" x-data="{ openedTab: '<?php echo e($menus[0][0]); ?>', openedIndex: 0 }" id="addNewRecordForm">
        <div class="w-full border-b">
            <div role="tablist" class="tabs grid grid-cols-5 w-fit relative">
                <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div role="tab" class="tab line-clamp-1"
                        @click="openedTab = '<?php echo e($menu[0]); ?>', openedIndex = <?php echo e($loop->index); ?>">
                        <?php echo e(__($menu[1])); ?>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="absolute -bottom-[1px] h-[2px] bg-cyan-500 w-1/5 transition-all duration-300 ease-in-out"
                    x-bind:style="{ left: (openedIndex * 20) + '%' }">
                </div>
            </div>
        </div>
        <input type="text" class="hidden" x-bind:value="openedTab" name="age_group">
        <div>
            <h2 class="text-xl font-bold"><?php echo e(__('Patient Information')); ?></h2>
            <p class="text-xs text-gray-500">
                <?php echo e(__("Select or add from name, you can also update the patient's information")); ?></p>
            <div class="gap-4 gap-y-2 grid lg:grid-cols-5 grid-cols-2 mt-2">
                <?php echo $__env->make('posyandu.partials.new.patient', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
        <div>
            <h2 class="text-xl font-bold"><?php echo e(__('Vital Information')); ?></h2>
            <div class="gap-4 gap-y-2 grid lg:grid-cols-5 grid-cols-2 mt-2">
                <?php echo $__env->make('posyandu.partials.new.vital', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
        <div class="overflow-y-hidden transition-all duration-500 ease-in-out origin-top"
            x-bind:class="{
                'max-h-0': openedIndex <= 1,
                'lg:max-h-36 max-h-full': openedIndex > 1
            }">
            <h2 class="text-xl font-bold"><?php echo e(__('Lab Results')); ?></h2>
            <div class="gap-4 gap-y-2 grid lg:grid-cols-5 grid-cols-2 mt-2">
                <?php echo $__env->make('posyandu.partials.new.lab', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
        <div class="overflow-y-hidden transition-all duration-500 ease-in-out origin-top"
            x-bind:class="{
                'max-h-0': openedIndex <= 2,
                'lg:max-h-60 max-h-full': openedIndex > 2
            }">
            <h2 class="text-xl font-bold"><?php echo e(__('Medical History')); ?></h2>
            <div class="gap-4 gap-y-2 grid lg:grid-cols-5  mt-2">
                <?php echo $__env->make('posyandu.partials.new.history', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>

            <div class="w-fit">
                <div class="block mt-4">
                    <label for="kb" class="inline-flex items-center">
                        <input id="kb" type="checkbox"
                            class="rounded border-gray-300 text-cyan-600 shadow-sm focus:ring-cyan-500" name="kb">
                        <span class="ms-2 text-sm text-gray-600"><?php echo e(__('Family Planning')); ?></span>
                    </label>
                </div>
                <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->createReport->get('kb'),'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->createReport->get('kb')),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
            </div>
        </div>
        <div class="flex w-fit">
            <?php if (isset($component)) { $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.secondary-button','data' => ['class' => 'mt-4 mr-4','type' => 'button']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('secondary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mt-4 mr-4','type' => 'button']); ?>
                <?php echo e(__('Cancel')); ?>

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $attributes = $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $component = $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginald411d1792bd6cc877d687758b753742c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald411d1792bd6cc877d687758b753742c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-button','data' => ['class' => 'mt-4','type' => 'submit']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('primary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mt-4','type' => 'submit']); ?>
                <?php echo e(__('Save')); ?>

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $attributes = $__attributesOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__attributesOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $component = $__componentOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__componentOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
        </div>
    </form>

    <?php if (! $__env->hasRenderedOnce('bef32cea-3d9f-47c5-bcdd-695641c89a04')): $__env->markAsRenderedOnce('bef32cea-3d9f-47c5-bcdd-695641c89a04');
$__env->startPush('scripts'); ?>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                const form = document.getElementById('addNewRecordForm');
                console.log("LODED")
                form.addEventListener('submit', (e) => {
                    e.preventDefault();
                    console.log("SUBMITED")
                    const formData = new FormData(form);
                    const url = '<?php echo e(route('posyandu.store')); ?>';

                    axios.post(url, formData, {
                            headers: {
                                'Content-Type': 'multipart/form-data'
                            }
                        })
                        .then(response => {
                            const data = response.data;
                            notyf.success("<?php echo e(__('Record saved')); ?>")
                            // clear form
                            form.reset();
                        })
                        .catch(error => {
                            if (error.response.data.errors) {
                                const errors = error.response.data.errors;
                                const keys = Object.keys(errors);
                                console.log(keys)
                                keys.forEach(key => {
                                    console.log(key)
                                    const input = form.querySelector(`[name="${key}"]`);
                                    const error = errors[key];
                                    if (input) {
                                        input.classList.add('border-red-500');
                                        const errorElement = document.createElement('p');
                                        errorElement.classList.add('text-red-500', 'text-xs',
                                            'mt-1');
                                        errorElement.textContent = error;
                                        const parent = input.parentElement;
                                        parent.appendChild(errorElement);
                                    }
                                })
                            } else {
                                notyf.error("<?php echo e(__('Failed to save record')); ?>")
                            }
                        });
                });
            });

            // get all input element and listen if changed remove the error
            const inputs = document.querySelectorAll('input, select, textarea');
            inputs.forEach(input => {
                input.addEventListener('change', function() {
                    this.classList.remove('border-red-500');
                    const parent = this.parentElement;
                    const errorElement = parent.querySelector('.text-red-500');
                    if (errorElement) {
                        errorElement.remove();
                    }
                });
            });
        </script>
    <?php $__env->stopPush(); endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /home/xirf/00.Projects/02.PHP/posyandu/resources/views/posyandu/new.blade.php ENDPATH**/ ?>