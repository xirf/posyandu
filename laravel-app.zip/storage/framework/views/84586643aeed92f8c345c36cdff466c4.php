<svg class="w-4 h-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" data-slot="icon">
  <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5"/>
</svg><?php /**PATH /home/xirf/00.Projects/02.PHP/posyandu/storage/framework/views/5f824d0ca4bcf8fa0a6d7f66cae5bc3f.blade.php ENDPATH**/ ?>